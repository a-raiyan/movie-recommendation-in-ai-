# Sample Python source code for movie recommendation system
print('Hello World!')